public interface Observer {
    void update(int temperature);
}